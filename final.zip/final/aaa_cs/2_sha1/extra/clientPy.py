import hashlib
import socket
import uuid

def hashEqui(key):
	msg = uuid.uuid4().hex
	return hashlib.sha256(msg.encode()+key.encode()).hexdigest()+":"+msg


port = 33207
host = "localhost"
s=socket.socket()
s.connect((host , port))

privateKey ="cl3"

decodedmsg = hashEqui(privateKey)

print "sending msg..."
s.send(decodedmsg)

print "msg sent..."

data = s.recv(1024)
print data

s.send("WORK DONE! Sent the data , please check")

s.close()

print"Connection refused "

