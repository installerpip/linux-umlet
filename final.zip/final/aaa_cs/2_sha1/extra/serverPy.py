import hashlib
import socket
import uuid

def chckpassword(data , key):
	password , msg = data.split(":")
	return password == hashlib.sha256(msg.encode()+key.encode()).hexdigest() 
	
port = 33207
host = "localhost"
s=socket.socket()
s.bind((host , port))
s.listen(5)

while True :
	conn , addr = s.accept()
	print "Connection established at " , addr
	
	data = conn.recv(1024)
	print data
	
	print "Checking the authentication of data received ..."
	
	publickey="cl3"

	if(chckpassword(data , publickey)):
		conn.send("Thank you for sending valid data..")
		print "Work done!!"
		conn.close()
	else:
		print "WRong"
