
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.interfaces.DSAParams;
import java.security.interfaces.DSAPrivateKey;
import java.security.interfaces.DSAPublicKey;
import java.security.spec.DSAPrivateKeySpec;
import java.security.spec.DSAPublicKeySpec;
import java.security.spec.KeySpec;

public class B_D_3 {
  public static void main(String[] argv) throws Exception {
    KeyPairGenerator keyGen = KeyPairGenerator.getInstance("DSA");////create instance of keypair offf keys(private aaand public)
   SecureRandom random = SecureRandom.getInstance("SHA1PRNG","SUN");// generate random keys //cryptographically strong random number generator (RNG)
    keyGen.initialize(1024,random);  //intialise keys size
    KeyPair keypair = keyGen.genKeyPair();  //get key pair
    DSAPrivateKey privateKey = (DSAPrivateKey) keypair.getPrivate();//get private key for DSA sig
    DSAPublicKey publicKey = (DSAPublicKey) keypair.getPublic();//get publickey for DSA sig

    DSAParams dsaParams = privateKey.getParams();  //get parameter for DSA
    BigInteger p = dsaParams.getP();
    BigInteger q = dsaParams.getQ();
    BigInteger g = dsaParams.getG();
    BigInteger x = privateKey.getX();
    BigInteger y = publicKey.getY();
    
    System.out.println("p length is "+p.bitLength());
    System.out.println("\np = " + p);
	System.out.println("\nq = " + q);
	System.out.println("\ng = " + g);
	System.out.println("\nx = " + x);
	System.out.println("\ny = " + y);

    // Create the DSA key factory
    KeyFactory keyFactory = KeyFactory.getInstance("DSA");//Key factories are used to convert keys  into key specifications, and vice versa.
    // Create the DSA private key
    KeySpec privateKeySpec = new DSAPrivateKeySpec(x, p, q, g);// stored nature of privatekey
     KeySpec publicKeySpec = new DSAPublicKeySpec(x, p, q, g);//stored nature of public key
    PrivateKey privateKey1 = keyFactory.generatePrivate(privateKeySpec);//Generates a private key object from the provided key specification (key material).
   PublicKey publicKey1 = keyFactory.generatePublic(publicKeySpec);//Generates a public key object from the provided key specification (key material).
   
   System.out.println("\nprivate = " + privateKey1);
	System.out.println("\npublic = " + publicKey1);

    byte[] buffer = new byte[1024];  //to stored input message
      //System.out.println(privateKey1.getAlgorithm());
    Signature sig = Signature.getInstance("SHA1withDSA", "SUN");//Returns a Signature object that implements the specified signature algorithm.
    sig.initSign(privateKey1);//Initialize this object for signing
    
    
     FileInputStream fis = new FileInputStream("a.txt");//get input file
        BufferedInputStream bufin = new BufferedInputStream(fis); 
       
        int len;
        
        while (bufin.available() != 0) {  // while if data exceed
            
          len = bufin.read(buffer);// input data pass to dsa object
        //System.out.println(buffer.toString());   
          sig.update(buffer, 0, len);//Updates the data to be signed or verified by a byte.
        }
        ;

        bufin.close();

        /*
         * Now that all the data to be signed has been read in, generate
         * a signature for it
         */

		/* Save the public key in a file */
        byte[] key = publicKey1.getEncoded();
        System.out.println("\nKey = " + key);
        FileOutputStream keyfos = new FileOutputStream("suepk");
        keyfos.write(key);

        keyfos.close();		
		
		
        byte[] realSig = sig.sign();//sign data
        System.out.println("\nSignature = " + realSig);
//char s[]=realSig.toString().toCharArray();
        /* Save the signature in a file */
        FileOutputStream sigfos = new FileOutputStream("sig");
        sigfos.write(realSig);

        sigfos.close();

        
  }
}

/*
 Output
 ============
 p length is 1024

p = 178011905478542266528237562450159990145232156369120674273274450314442865788737020770612695252123463079567156784778466449970650770920727857050009668388144034129745221171818506047231150039301079959358067395348717066319802262019714966524135060945913707594956514672855690606794135837542707371727429551343320695239

q = 864205495604807476120572616017955259175325408501

g = 174068207532402095185811980123523436538604490794561350978495831040599953488455823147851597408940950725307797094915759492368300574252438761037084473467180148876118103083043754985190983472601550494691329488083395492313850000361646482644608492304078721818959999056496097769368017749273708962006689187956744210730

x = 647178039903163340408870501938763940308236924782

y = 10104010934842892990778178282973423858799931496238293026590652324621370161510068148970936490542971881863328934931898852212442792592935251454714615262333193311042557541794872801625961533580620054988365114537980088516696350168928410957229628556855794195578221730705550656484599020580149362274519585768065851096

private = sun.security.provider.DSAPrivateKey@fffe546a

public = Sun DSA Public Key
    Parameters:
    p:
    fd7f5381 1d751229 52df4a9c 2eece4e7 f611b752 3cef4400 c31e3f80 b6512669
    455d4022 51fb593d 8d58fabf c5f5ba30 f6cb9b55 6cd7813b 801d346f f26660b7
    6b9950a5 a49f9fe8 047b1022 c24fbba9 d7feb7c6 1bf83b57 e7c6a8a6 150f04fb
    83f6d3c5 1ec30235 54135a16 9132f675 f3ae2b61 d72aeff2 2203199d d14801c7
    q:
    9760508f 15230bcc b292b982 a2eb840b f0581cf5
    g:
    f7e1a085 d69b3dde cbbcab5c 36b857b9 7994afbb fa3aea82 f9574c0b 3d078267
    5159578e bad4594f e6710710 8180b449 167123e8 4c281613 b7cf0932 8cc8a6e1
    3c167a8b 547c8d28 e0a3ae1e 2bb3a675 916ea37f 0bfa2135 62f1fb62 7a01243b
    cca4f1be a8519089 a883dfe1 5ae59f06 928b665e 807b5525 64014c3b fecf492a

  y:
    715c778c b4bdf7c1 97e8023a 1d5b7c37 9798776e


Key = [B@7490649e

Signature = [B@10ca6ba3

*/
