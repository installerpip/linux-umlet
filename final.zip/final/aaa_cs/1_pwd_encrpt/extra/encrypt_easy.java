import java.io.BufferedReader;
import java.io.InputStreamReader;

public class A6
{
	
	public StringBuffer CaesarC(String Enc,int s)
	{
		StringBuffer res=new StringBuffer();
		char ch;
		for(int i=0;i<Enc.length();i++)
		{
			if(Character.isUpperCase(Enc.charAt(i)))
				 ch=(char)((((int)Enc.charAt(i)+s-65) % 26)+65);
			
			else
				
				ch=(char)((((int)Enc.charAt(i)+s-97) % 26)+97);
			res.append(ch);
			
		}
		
		return res;
	}
	
	public StringBuffer Vernam(String Enc,String key)
	{
		StringBuffer res=new StringBuffer();
		int size=Enc.length();
		for(int i=0;i<size;i++)
		{
			char ch=(char)((((int)Enc.charAt(i)+(int)key.charAt(i))%26)+65);
			res.append(ch);
		}
		
		
		return res;
	}
	
	public StringBuffer Transposition(String Enc,String key)
	{
		StringBuffer res=new StringBuffer();
		int size=key.length();
		char arr[][]=new char[size][size];
		int k=0,i=0,j=0;
		int flag1=0;
		char ch;
		
		
		for(i=0;i<size;i++)
		{

			for(j=0;j<size;j++)
			{
				
				arr[i][j]=Enc.charAt(k);
				k++;
				
				if(k==Enc.length())
				{
					
					flag1=1;
					break;
				}
			}
			if(flag1==1)
			{
				
				break;
			}
		}
		
		for(;i<size;i++) 
		{
			for(;j<size;j++)
			{
				arr[i][j]='*';
			}
			j=0;
		}
		
		
		for(i=0;i<size;i++)
		{
			int p=Integer.parseInt(Character.toString(key.charAt(i)));
			for(j=0;j<size;j++)
			{
				if(arr[j][p-1]!='*')
				{
					ch=arr[j][p-1];
					res.append(ch);
				}
			}
		}
		return res;
	}
	
	
	public static void main(String args[]) throws Exception
	{
		String Enc="Helloworld";
		StringBuffer res=new StringBuffer();
		int shift=4;
		String key="hithisisas";
		String key2="54321";
		System.out.println("1.Caesar cipher");
		System.out.println("2.Vernam");
		System.out.println("3.Tansposition");
		System.out.println("Enter Choice: ");
		
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		String s=br.readLine();
		A6 obj=new A6();
		int l=Integer.parseInt(s);
		if(l==1)
			res=obj.CaesarC(Enc, shift);
			
		
		if(l==2)
			 res=obj.Vernam(Enc,key);
		
		else
			 res=obj.Transposition(Enc,key2);
			 
		System.out.println("Message : "+ Enc);
		System.out.println("Encrypted Cipher : "+ res);
		
	}

}
