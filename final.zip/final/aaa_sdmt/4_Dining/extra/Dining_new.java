import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;



public class Dining 
{
	Lock forks[]=new ReentrantLock[5];
	public static void main(String[] args) 
	{
		
	
		
		Dining d=new Dining();
		
		for (int i = 0; i < 5; i++) 
		{
			d.forks[i] = new ReentrantLock();
		}
		Thread p1 = new Thread(new Philospher(d.forks[4], d.forks[0], "first"));
		Thread p2 = new Thread(new Philospher(d.forks[0], d.forks[1], "second"));
		Thread p3 = new Thread(new Philospher(d.forks[1], d.forks[2], "third"));
		Thread p4 = new Thread(new Philospher(d.forks[2], d.forks[3], "fourth"));
		Thread p5 = new Thread(new Philospher(d.forks[3], d.forks[4], "fifth"));
		p1.start();
		p2.start();
		p3.start();
		p4.start();
		p5.start();

	}

}

class Philospher implements Runnable
{
	Lock leftFork = new ReentrantLock();
	Lock rightFork = new ReentrantLock();
	String name;
	static MongoClient mongoClient ;
	static MongoDatabase db;
	static
	{
		mongoClient = new MongoClient("localhost");
		 db = mongoClient.getDatabase("dining");
		 try {
			 db.createCollection("mycol");
			 
				 
			 }
		 catch(Exception ex)
		 {
			 
		 }
	}
	public Philospher(Lock left,Lock right,String name1) 
	{
		
		leftFork=left;
		rightFork=right;
		name=name1;
		
	}

	@Override
	public void run()
	{
		while(true)
		{
			think(name);
			eat(leftFork, rightFork, name);
		}
		
	}
	
	public static void eat(Lock left,Lock right,String name1)
	{
		while(!(left.tryLock()&&right.tryLock()))
		{
			if(left.tryLock())
			left.unlock();
			if(right.tryLock())
			right.unlock();
		}
		
		System.out.println("Philospher "+name1+" is eating");
		Document doc = new Document(name1, " is eating");
		MongoCollection<Document> coll = db.getCollection("mycol");
		coll.insertOne(doc);
		
		left.unlock();
		right.unlock();
		System.out.println("Philospher "+name1+" is done eating");
		doc = new Document(name1, " is done eating");
		coll.insertOne(doc);
		
		
	}
	
	public static void think(String name)
	{
		System.out.println(name + " is thinking...");
		try
		{
			Document doc = new Document(name, " thinking...");
			MongoCollection<Document> coll = db.getCollection("mycol");
			coll.insertOne(doc);
			Random ran=new Random();
			int rand=ran.nextInt(10000);
			Thread.sleep(rand);
		}
		catch(Exception ex)
		{
			
		}
		
	}
}